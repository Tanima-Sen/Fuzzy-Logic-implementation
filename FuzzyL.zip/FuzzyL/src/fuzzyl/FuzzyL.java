/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fuzzyl;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;
/**
 *
 * @author Tanima
 */
public class FuzzyL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int current_temperature[][] = {{8, 15}, {13, 19}, {18, 22}, {21, 27}, {26, 32}, {31, 39}, {38, 44}};
		String membership_temperature[] = {"COLD", "COOL", "NORMAL", "WARM", "HOT", "VERY-HOT", "EXTRA-HOT"}; 
		int temp1 = 0, temp2 = 0, deviation_temp_1=0, deviation_temp_2=0;
                int temp[]={0,0};
                int dev [] ={0,0};
		
		float current_temperature_deviation[][] = {{-26, -18.5f}, { -19.5f, -12}, {-13, -6}, {-7, 1}, {-2, 2}, {1, 10.5f}, {9, 18}};
		String membership_deviation[] = {"NE2", "NE1", "NL", "NS", "O", "PS", "PL"}; 

		float heat_fan_speed[][] = {{0, 5}, { 0, 45}, {35, 65}, {60, 100}};
		String membership_heat_fan_speed[] = {"STOP", "HEAT-SLOW", "HEAT-MEDIUM", "HEAT-FAST"}; 
		
		float cool_fan_speed[][] = {{0, 5}, { 0, 30}, {25, 50}, {45, 80}, {75, 100}};
		String membership_cool_fan_speed[] = {"STOP", "COOL-SLOW", "COOL-MEDIUM", "COOL-FAST", "COOL-V.FAST"}; 
		
		String rule[][] ={{"Cold", "PL", "Heat-Fast", "Stop"}, 
                                  {"Cold", "PS", "Heat-Medium", "Stop"}, 
				  {"Cool", "PL", "Heat-Medium", "Stop"}, {"Cool", "PS", "Heat-Slow", "Stop"}, 
				  {"Cool", "O", "Stop", "Stop"}, {"Cool", "NS", "Stop", "Cool-Slow"}, 
				  {"Normal", "PS", "Heat-Slow", "Stop"}, {"Normal", "O", "Stop", "Stop"}, 
				  {"Normal", "NS", "Stop", "Cool-Slow"}, {"Warm", "PS", "Heat-Slow", "Stop"}, 
				  {"Warm", "O", "Stop", "Stop"}, {"Warm", "NS", "Stop", "Cool-Slow"}, 
				  {"Warm", "NL", "Stop", "Cool-Medium"}, {"Hot", "NS", "Stop", "Cool-Slow"}, 
				  {"Hot", "NL", "Stop", "Cool-Medium"}, {"Hot", "NE1", "Stop", "Cool-Fast"}, 
				  {"Very-Hot", "NS", "Stop", "Cool-Slow"}, {"Very-Hot", "NL", "Stop", "Cool-Medium"}, 
				  {"Very-Hot", "NE1", "Stop", "Cool-Fast"}, {"Very-Hot", "NE2", "Stop", "Cool-V.Fast"}, 
				  {"Extra-Hot", "NE1", "Stop", "Cool-Fast"}, {"Extra-Hot", "NE2", "Stop", "Cool-V.Fast"} };
		
		String membership_rule[] = {"CURRENT-TEMP", "DEVIATION FROM SET-TEMP", "HEAT-FAN-SPEED", "COOL-FAN-SPEED"};
		Scanner sc = new Scanner(System.in);
		System.out.print("Input Current Temperature Value within 8-44: ");
                float current_temp_value = sc.nextFloat();
		
                System.out.print("Input Current Humidity Value within 0-100: ");
                
                float current_humidity_value = sc.nextFloat();
                System.out.println("**********Temperature**********");
                String membership_temperature_value []={ " ", " "};
                String membership_deviation_value []={ " ", " "};
                String membership_heat_fan_value []={ " ", " "," "," "};
                String membership_cool_fan_value []={ " ", " "," "," "};
                
		float set_temperature = 23;
                
                //Temperature Calculation
                int j=0;
                for(int i=0;i<current_temperature.length;i++){
                    if(current_temp_value>= current_temperature[i][0] && current_temp_value<=current_temperature[i][1]){
                        temp[j]=i;
                        membership_temperature_value[j] =membership_temperature[i];
                        j++;
                        
                        
                    }
                    
                }
                System.out.print("Temperature Membership function Output is : ");
                for(int i=0;i<j;i++){
                    System.out.print(membership_temperature_value[i] );
                    System.out.print("  ");
                }
                //Temperature Deviation Calculation
                int k=0;
                float devition_temperature = set_temperature - current_temp_value;
                for(int i=0;i<current_temperature_deviation.length;i++){
                    if(devition_temperature>= current_temperature_deviation[i][0] && devition_temperature<=current_temperature_deviation[i][1]){
                        dev[k]=i;
                        membership_deviation_value[k] =membership_deviation[i];
                        k++;
                        
                        
                    }
                    
                }
                System.out.println(" ");
                System.out.print("Deviation Membership function Output is : ");
                for(int i=0;i<k;i++){
                    System.out.print(membership_deviation_value[i] );
                    System.out.print("  ");
                }
                System.out.println(" ");
                //Fuzzy Temperature Calculation
                float fuzzy_temperature_value [] ={0,0}; 
                
                fuzzy_temperature_value [1]= (current_temperature[temp[0]][1]-current_temp_value)/current_temperature[temp[0]][1];
                fuzzy_temperature_value [0] = 1-fuzzy_temperature_value [1];
                System.out.print("Fuzzy Temperature value is :");
                System.out.print(fuzzy_temperature_value [0]+ "  "+ fuzzy_temperature_value [1] );
                
                System.out.println(" ");
                
                //Fuzzy deviation Calculation
                
                float fuzzy_deviation_value [] ={0,0};
                
                fuzzy_deviation_value [1]= (current_temperature_deviation[dev[0]][1]-devition_temperature)/current_temperature_deviation[dev[0]][1];
                fuzzy_deviation_value [0] = 1-fuzzy_deviation_value [1];
                System.out.print("Fuzzy Deviation value is :");
                System.out.print(fuzzy_deviation_value [0]+ "  "+ fuzzy_deviation_value [1] );
                
                //Inference Engine Calculation
                
                float R [] = {0,0,0,0};
                int q=0;
                for(int i=0;i<fuzzy_temperature_value.length;i++){
                    for(int p=0;p<fuzzy_deviation_value.length;p++){
                        if(fuzzy_temperature_value[i]<  fuzzy_deviation_value[p]){
                            R [q] = fuzzy_temperature_value[i];
                            q++;
                        }
                        else{
                          R [q] =  fuzzy_deviation_value[p];
                          q++;
                        }
                    }
                    
                }
           
                System.out.println("");
                System.out.print("Minimum Value from Fuzzy Temp and Deviation is :");
                for (int i=0;i<R.length;i++){
                   System.out.print("  "+ R[i]);
                   
                }
                
                //Rule selector
               int r=0;
               int s=0;
               
               System.out.println("");
               System.out.println("");
               System.out.println("Rule Generated is :");
               for(int i=0;i<rule.length;i++){
                   for(int t =0;t<membership_temperature_value.length;t++){
                     if(membership_temperature_value[t].equalsIgnoreCase(rule[i][0])){
                       
                       for( s =0;s<membership_deviation_value.length;s++){
                           //System.out.print( "aaaaaa"+membership_deviation_value[s]);
                           if(membership_deviation_value[s].equalsIgnoreCase(rule[i][1])){
                               System.out.print( membership_temperature_value[t]+ "  ");
                               System.out.print( membership_deviation_value[s]+ "  ");
                               membership_heat_fan_value[r] = rule[i][2];
                               
                               System.out.print(membership_heat_fan_value[r]+ "  " );
                               membership_cool_fan_value[r] = rule [i][3];
                               System.out.print(membership_cool_fan_value[r] + "  ");
                               r++;
                               System.out.println("");
                           }
                       }
                   }
                   
                   }
                     
               }
               
               /*Humidity h = new Humidity();
               System.out.println("");
               System.out.println("");
               System.out.println("**********Humidity**********");
               h.humidifier(current_temp_value, set_temperature, current_humidity_value);*/         
                  
               
               System.out.println("");
               System.out.println("");
               System.out.print("Heat Fan Speed is: ");
               for(int i=0;i<membership_heat_fan_value.length;i++){
                  System.out.print(membership_heat_fan_value [i]+ " "); 
               }
               System.out.println("");
               System.out.print("Cool Fan Speed is: ");
               for(int i=0;i<membership_cool_fan_value.length;i++){
                  System.out.print(membership_cool_fan_value [i]+ " "); 
               }
               
               
               // Rule evaluation
               
               float heat_fan_speed_value [] ={0,0,0,0};
               float cool_fan_speed_value [] ={0,0,0,0};
               System.out.println("");
               System.out.println("");
               int temp_h=0;
               System.out.print("Heat Fan Speed is :");
               for(int i=0;i<membership_heat_fan_value.length;i++){
                   for(int u=0;u<membership_heat_fan_speed.length;u++){
                     if(membership_heat_fan_value[i].equalsIgnoreCase(membership_heat_fan_speed[u])){
                         heat_fan_speed_value [temp_h] = ((heat_fan_speed[u][0]+heat_fan_speed[u][1])/2)/100;
                         System.out.print( membership_heat_fan_value[i]+ "=  "+heat_fan_speed_value [temp_h]+"  ");
                         temp_h++;
                       
                   }   
                   }
                  
               }
               System.out.println("");
               System.out.print("Cool Fan Speed is :");
               int temp_c =0;
               for(int i=0;i<membership_cool_fan_value.length;i++){
                   for(int u=0;u<membership_cool_fan_speed.length;u++){
                     if(membership_cool_fan_value[i].equalsIgnoreCase(membership_cool_fan_speed[u])){
                         cool_fan_speed_value [temp_c ] = ((cool_fan_speed[u][0]+cool_fan_speed[u][1])/2)/100;
                         System.out.print( membership_cool_fan_value[i]+ "=  "+cool_fan_speed_value [temp_c ]+"  ");
                         temp_c++;
                       
                   }   
                   }
                  
               }
               
               //Defuzzification
               
               float sum_R_h =0,sum_R_c=0,sum_heat_fan_speed_value=0,sum_cool_fan_speed_value=0;
               System.out.println("");
               System.out.println("");
               for(int i=0;i<temp_h;i++){
                   sum_R_h+= R[i];
                       
               }
               for(int i=0;i<temp_c;i++){
                   sum_R_c+= R[i];
                       
               }
               System.out.println("Sum of R for heat fan is :" + sum_R_h);
               System.out.println("Sum of R for cool fan is :" + sum_R_c);
               System.out.println("");
               for(int i=0;i<4;i++){
                   
                       sum_heat_fan_speed_value += heat_fan_speed_value[i]*R[i];
                }
               
              for(int i=0;i<4;i++){
                   
                       sum_cool_fan_speed_value += cool_fan_speed_value[i]*R[i];
                    
                }
            
               sum_heat_fan_speed_value = (sum_heat_fan_speed_value/sum_R_h)*100;
               sum_cool_fan_speed_value = (sum_cool_fan_speed_value/sum_R_c)*100;
               System.out.println("Heat Fan Speed is :" + sum_heat_fan_speed_value +"%");
               System.out.println("Cool Fan Speed is :" + sum_cool_fan_speed_value+ "%");
               
               
               Humidity h = new Humidity();
               System.out.println("");
               System.out.println("");
               System.out.println("**********Humidity**********");
               h.humidifier(current_temp_value, set_temperature, current_humidity_value);
    }
    
}
