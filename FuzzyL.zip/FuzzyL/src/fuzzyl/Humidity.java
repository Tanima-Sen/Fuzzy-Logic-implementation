/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fuzzyl;

/**
 *
 * @author Tanima
 */
class Humidity {

    void humidifier(float current_temp_value, float set_temperature, float current_humidity_value) {
        float current_temperature_ranges[][] = {{16, 22.5f}, {22, 28}};
    String membership_temperature_ranges[] = {"Temp-range-A", "Temp-range-B"};
    
    int temp = 0, temp2 = 0, deviation_temp_1=0, deviation_temp_2=0;
                int temp3[]={0,0};
                int temp4[]={0,0};
                int dev [] ={0,0};
    int current_humidity[][] = {{0, 21}, {20, 43}, {42, 48}, {46, 54}, {53, 75}, {70, 100}};           
    String membership_humidity[] = {"DRY", "NTD", "S-1", "S-2", "NTW", "WET"};
    float humidifier_ranges[][] = {{0, 5}, {4.5f, 35}, {28, 62}, {60, 100}};
    String humidifier_membership[] = {"STOP", "SLOW", "MEDIUM", "FAST"};
    float exhaust_fan_ranges[][] = {{0, 5}, {4.5f, 35}, {28, 62}, {60, 100}};
    String exhaust_fan_membership[] = {"STOP", "SLOW", "MEDIUM", "FAST"};
    
    String rule[][] ={
                        {"Temp-Range-A", "DRY", "Fast", "Stop"}, 
                        {"Temp-Range-A", "NTD", "Medium", "Stop"}, 
		        {"Temp-Range-A", "S-1", "Stop", "Stop"},
                        {"Temp-Range-A", "S-2", "Stop", "Slow"}, 
		        {"Temp-Range-A", "NTW", "Stop", "Medium"},
                        {"Temp-Range-A", "WET", "Stop", "Fast"}, 
                        {"Temp-Range-B", "DRY", "Fast", "Stop"},
                        {"Temp-Range-B", "NTD", "Medium", "Stop"}, 
			{"Temp-Range-B", "S-1", "Slow", "Stop"},
                        {"Temp-Range-B", "S-2", "Heat-Slow", "Stop"}, 
                        {"Temp-Range-B", "O", "Stop", "Stop"},
                        {"Temp-Range-B", "NS", "Stop", "Cool-Slow"}
                    };
    
                String membership_temperature_value []={ " ", " "};
                String membership_humidity_value []={ " ", " "};
                String membership_humidifier_value []={ " ", " "," "," "};
                String membership_exhusted_fan_value []={ " ", " "," "," "};
                
                int j=0;
                for(int i=0;i<current_temperature_ranges.length;i++){
                    if(current_temp_value>= current_temperature_ranges[i][0] && current_temp_value<=current_temperature_ranges[i][1]){
                        temp3[j]=i;
                        membership_temperature_value[j] =membership_temperature_ranges[i];
                        j++;     
                    }     
                }
                
                System.out.print("Temperature Membership function Output is : ");
                for(int i=0;i<j;i++){
                    System.out.print(membership_temperature_value[i] );
                    System.out.print("  ");
                }
                
                int k=0;
                for(int i=0;i<current_humidity.length;i++){
                    if(current_humidity_value>= current_humidity[i][0] && current_humidity_value<=current_humidity[i][1]){
                        temp4[k]=i;
                        membership_humidity_value[k] =membership_humidity[i];
                        k++;   
                    }
                }
                
                System.out.println(" ");
                System.out.print("Humidity Membership function Output is : ");
                for(int i=0;i<k;i++){
                    System.out.print(membership_humidity_value[i] );
                    System.out.print("  ");
                }
                
               int r=0;
               int s=0;
               
               System.out.println("");
               System.out.println("");
               System.out.println("Rule Generated is :");
               for(int i=0;i<rule.length;i++){
                   for(int t =0;t<membership_temperature_value.length;t++){
                     if(membership_temperature_value[t].equalsIgnoreCase(rule[i][0])){
                       
                       for( s =0;s<membership_humidity_value.length;s++){
                           //System.out.print( "aaaaaa"+membership_humidity_value[s]);
                           if(membership_humidity_value[s].equalsIgnoreCase(rule[i][1])){
                               System.out.print( membership_temperature_value[t]+ "  ");
                               System.out.print( membership_humidity_value[s]+ "  ");
                               membership_humidifier_value[r] = rule[i][2];
                               System.out.print(membership_humidifier_value[r]+ "  " );
							   
                               membership_exhusted_fan_value[r] = rule [i][3];
                               System.out.print(membership_exhusted_fan_value[r] + "  ");
                               r++;
                               System.out.println("");
                           }
                        }
                     }
                   
                  }     
               }
    }
    
}
